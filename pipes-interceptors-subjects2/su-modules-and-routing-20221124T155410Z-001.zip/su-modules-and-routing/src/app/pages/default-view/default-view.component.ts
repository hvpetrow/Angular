import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-default-view',
  templateUrl: './default-view.component.html',
  styleUrls: ['./default-view.component.css']
})
export class DefaultViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
