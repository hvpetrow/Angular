import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-profile-albums',
  templateUrl: './customer-profile-albums.component.html',
  styleUrls: ['./customer-profile-albums.component.css']
})
export class CustomerProfileAlbumsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
